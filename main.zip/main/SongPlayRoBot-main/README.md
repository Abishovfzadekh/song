# Check Our New Bot Repo & Video :

[Video](https://youtu.be/3pN0W4KzzNY) 🎥

Repo : [SongProBot 🎻](https://GitHub.Com/TamilBots/SongPlayRoBot)

Bot : [Song Pro Bot 🧚‍](https://t.me/SongProBot)

## SongPlayRoBot
3X Fast Telethon Based Bot ⚜

Open Source Bot 👨🏻‍💻

Demo : [SongProBot  🎻](https://t.me/SongProBot) 💃🏻

Easy To Deploy 🤗

# Click Below Image to Deploy
[![Deploy](https://telegra.ph/file/9d337b3414bbf8e39ba79.jpg)](https://heroku.com/deploy?template=https://github.com/IVETRI/SongPlayRoBot.git)
# DEPLOY
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/IVETRI/SongPlayRoBot.git)

## Group
You can also join our support group [HERE!](https://t.me/TamilSupport) 👨🏻‍💻

# Report error
Report your problem along with your name to This Person 📲 [iMvEtRi🧑‍💻](https://t.me/IMVETRI) 😪



